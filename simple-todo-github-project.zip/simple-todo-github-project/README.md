# My To-Do List ✨

A beginner-friendly To-Do List web app made with HTML, CSS and JavaScript.

## Features
- Add tasks
- Mark tasks as completed
- Delete individual tasks
- Clear all completed tasks
- Save tasks in the browser using localStorage

## How to run
1. Download or clone this repository.
2. Open `index.html` in your browser.
3. Start adding tasks!

No installation is required.

## Technologies
- HTML
- CSS
- JavaScript
- Browser localStorage

## GitHub upload
Create a new repository on GitHub, then upload these project files. Give the repository a name such as `simple-todo-list`.
